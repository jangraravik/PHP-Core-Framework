This script reads an standard words file (one word per line) and saves
a new word file with the format needed by the cool-php-capcha script.

To prevent remote web access, the output file will be a PHP script
and must have the .php extension 

Usage: importwords.php <infile> <outfile>

Example: importwords.php english.txt en.php


